# Virtual module used by build_behaviour.
# Functions are injected here by ci_build.py during the "run" function.
